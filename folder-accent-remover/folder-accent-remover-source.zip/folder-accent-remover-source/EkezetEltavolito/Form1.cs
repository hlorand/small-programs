﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Globalization;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog fbd = new FolderBrowserDialog();
            if (fbd.ShowDialog() == System.Windows.Forms.DialogResult.OK) {
                textBox1.Text = fbd.SelectedPath;

                string path = textBox1.Text;
                string[] dirs = Directory.GetDirectories(path);

                foreach (string dir in dirs)
                {
                    string source = dir;
                    string destination = System.IO.Directory.GetParent(dir).FullName + "\\" + RemoveDiacritics(new DirectoryInfo(dir).Name);
                    listBox1.Items.Add(new DirectoryInfo(source).Name);
                    listBox2.Items.Add(RemoveDiacritics(new DirectoryInfo(destination).Name));
                }
            }
        }

        static string RemoveDiacritics(string text)
        {
            var normalizedString = text.Normalize(NormalizationForm.FormD);
            var stringBuilder = new StringBuilder();

            foreach (var c in normalizedString)
            {
                var unicodeCategory = CharUnicodeInfo.GetUnicodeCategory(c);
                if (unicodeCategory != UnicodeCategory.NonSpacingMark)
                {
                    stringBuilder.Append(c);
                }
            }

            return stringBuilder.ToString().Normalize(NormalizationForm.FormC);
        }



       

        private void button3_Click(object sender, EventArgs e)
        {
            if (listBox1.Items.Count == 0)
            {
                MessageBox.Show("Adj meg egy elérési utat!");
            }
            else
            {
                string path = textBox1.Text;
                string[] dirs = Directory.GetDirectories(path);

                foreach (string dir in dirs)
                {
                    string source = dir;
                    string destination = System.IO.Directory.GetParent(dir).FullName + "\\" + RemoveDiacritics(new DirectoryInfo(dir).Name);
                    if (String.Compare(source,destination) != 0) { Directory.Move(source, destination); }
                }
                listBox1.Items.Clear();
                listBox2.Items.Clear();
                MessageBox.Show("Az eltávolítás sikeresen befejeződött!");
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_MouseEnter(object sender, EventArgs e)
        {
            label4.Text = "www.hlorand.hu";
        }

        private void label4_MouseLeave(object sender, EventArgs e)
        {
            label4.Text = "Horváth Loránd";
        }
    }
}
